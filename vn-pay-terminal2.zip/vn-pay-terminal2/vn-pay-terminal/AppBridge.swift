// 创建桥接文件 AppBridge.swift
import Foundation

// 正确生成的Swift桥接协议应类似：
@objc public protocol AppNotifier : NSObjectProtocol {
    @objc func onNotify(_ msg: String?)
}
