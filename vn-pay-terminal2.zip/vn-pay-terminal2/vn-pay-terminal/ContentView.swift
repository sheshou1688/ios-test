import SwiftUI
import App
import Photos

// ✅ 必须使用 AppNotifierProtocol 作为协议名
class GoCallbackHandler: NSObject, AppNotifierProtocol { // 注意 Protocol 后缀
    @objc func onNotify(_ msg: String?) { // 参数必须为 Optional
        guard let validMsg = msg, !validMsg.isEmpty else { return }
                
                // 调用统一工具类
                QRCodeManager.shared.generateAndSaveQRCode(content: validMsg) { success, error in
                    DispatchQueue.main.async {
                        if success {
                            print("✅ 回调二维码保存成功")
                        } else if let error = error {
                            print("❌ 回调保存失败: \(error.localizedDescription)")
                        }
                    }
                }
    }
}

struct ContentView: View {
    // 初始化回调处理器
    private let handler = GoCallbackHandler()
    
    
    var body: some View {
        VStack(spacing: 20) { // 增加整体垂直间距
            Text("打开app后,3秒后切到后台,请确保真后台已经打开!!!")
                .font(.headline)
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color.blue.opacity(0.1))
                .cornerRadius(12)
                .padding(.horizontal)
            
            // 按钮容器
            VStack(spacing: 15) { // 按钮之间间距
                // 生成按钮
                Button(action: generateSampleQRCode) {
                    HStack {
                        Image(systemName: "qrcode")
                        Text("生成测试二维码")
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 15)
                    .background(
                        LinearGradient(
                            colors: [.blue, .purple],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .foregroundColor(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                    .shadow(color: .blue.opacity(0.4), radius: 8, y: 4)
                }
                .buttonStyle(ScaleButtonStyle()) // 添加按压动画
                
                // 删除按钮
                Button(role: .destructive, action: deleteQRCode) {
                    HStack {
                        Image(systemName: "trash")
                        Text("删除所有图片")
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 15)
                    .background(
                        LinearGradient(
                            colors: [.red, .orange],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .foregroundColor(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                    .shadow(color: .red.opacity(0.4), radius: 8, y: 4)
                }
                .buttonStyle(ScaleButtonStyle())
            }
            .padding(.horizontal) // 两侧留白
        }
        .onAppear {
            AppSetNotifier(handler)// 绑定通知处理器
            startBackgroundOperations()
        }
    }
    
    // MARK: - 原有逻辑封装
    private func startBackgroundOperations() {
        print("Starting App with AppStartApp()")
        
        // 后台初始化
        DispatchQueue.global(qos: .background).async {
            AppStartApp()
        }
        
        // 3秒后切后台
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            UIApplication.shared.perform(#selector(NSXPCConnection.suspend))
        }
    }
    
    // MARK: - 二维码工具类调用
    private func generateSampleQRCode() {
        let testContent = "00020101021238540010A00000072701240006970436011010275884620208QRIBFTTA5303704540750202805802VN62120808p683z1366304EB08"
        
        // 调用统一工具类
               QRCodeManager.shared.generateAndSaveQRCode(content: testContent) { success, error in
                   DispatchQueue.main.async {
                       if success {
                           print("✅ 手动生成二维码成功")
                       } else if let error = error {
                           print("❌ 手动生成错误: \(error.localizedDescription)")
                       }
                   }
               }
    }
    
    private func deleteQRCode() {
        QRCodeManager.shared.deleteAllPhotos { success, error in
                   if success {
                       print("✅ 删除成功")
                       showAlert(title: "完成", message: "已删除所有图片")
                   } else if let error = error {
                       print("❌ 删除失败: \(error.localizedDescription)")
                       showAlert(title: "错误", message: error.localizedDescription)
                   }
               }
    }
    
    // MARK: - 提示弹窗
        private func showAlert(title: String, message: String) {
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "确定", style: .default))
            
            // 获取当前窗口的根视图控制器
            if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
               let rootVC = windowScene.windows.first?.rootViewController {
                rootVC.present(alert, animated: true)
            }
        }
}

#Preview {
    ContentView()
}


// 按压动画组件
struct ScaleButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.95 : 1.0)
            .opacity(configuration.isPressed ? 0.9 : 1.0)
            .animation(.easeInOut(duration: 0.2), value: configuration.isPressed)
    }
}
