// QRCodeManager.swift
import UIKit
import Photos

class QRCodeManager: NSObject {
    static let shared = QRCodeManager()
    
    // MARK: - 公共方法
    func generateAndSaveQRCode(
        content: String,
        completion: @escaping (Bool, Error?) -> Void
    ) {
        // 1. 检查有效内容
        guard !content.isEmpty else {
            completion(false, NSError(domain: "QRCodeError", code: 1001, userInfo: [NSLocalizedDescriptionKey: "空内容"]))
            return
        }
        
        // 2. 异步生成（避免阻塞主线程）
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else { return }
            
            guard let qrImage = self.generateQRCode(from: content) else {
                DispatchQueue.main.async {
                    completion(false, NSError(domain: "QRCodeError", code: 1002, userInfo: [NSLocalizedDescriptionKey: "生成失败"]))
                }
                return
            }
            
            // 3. 保存到相册（主线程处理）
            DispatchQueue.main.async {
                self.saveToAlbum(image: qrImage, completion: completion)
            }
        }
    }
    
    // MARK: - 私有方法
    private func generateQRCode(from string: String) -> UIImage? {
        guard let data = string.data(using: .utf8),
              let filter = CIFilter(name: "CIQRCodeGenerator") else {
            return nil
        }
        
        filter.setValue(data, forKey: "inputMessage")
        filter.setValue("H", forKey: "inputCorrectionLevel")
        
        guard let outputImage = filter.outputImage else { return nil }
        
        // 使用Core Graphics提高清晰度
        let transform = CGAffineTransform(scaleX: 10, y: 10)
        let scaledImage = outputImage.transformed(by: transform)
        
        let context = CIContext()
        guard let cgImage = context.createCGImage(scaledImage, from: scaledImage.extent) else {
            return nil
        }
        
        return UIImage(cgImage: cgImage)
    }
    
    private func saveToAlbum(image: UIImage, completion: @escaping (Bool, Error?) -> Void) {
        // 权限检查逻辑
        let status = PHPhotoLibrary.authorizationStatus()
        
        switch status {
        case .authorized:
            performSave(image: image, completion: completion)
        case .notDetermined:
            PHPhotoLibrary.requestAuthorization { [weak self] newStatus in
                if newStatus == .authorized {
                    self?.performSave(image: image, completion: completion)
                } else {
                    completion(false, NSError(domain: "PhotoError", code: 2001, userInfo: [NSLocalizedDescriptionKey: "未授权"]))
                }
            }
        default:
            completion(false, NSError(domain: "PhotoError", code: 2002, userInfo: [NSLocalizedDescriptionKey: "相册访问被拒绝"]))
        }
    }
    
    // 关键点 2: 使用正确的选择器签名
        @objc func image(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
            completionHandler?(error == nil, error)
            completionHandler = nil
        }
    
    private func performSave(image: UIImage, completion: @escaping (Bool, Error?) -> Void) {
            self.completionHandler = completion
            
            // 关键点 3: 使用正确的上下文信息
            let context = UnsafeMutableRawPointer(Unmanaged.passUnretained(self).toOpaque())
            
            UIImageWriteToSavedPhotosAlbum(
                image,
                self, // 关键点 4: 必须使用 NSObject 实例
                #selector(image(_:didFinishSavingWithError:contextInfo:)),
                context
            )
        }
    
    // MARK: - 保存回调处理
    private var completionHandler: ((Bool, Error?) -> Void)?
    
    @objc private func imageSaved(
        _ image: UIImage,
        didFinishSavingWithError error: Error?,
        contextInfo: UnsafeRawPointer
    ) {
        if let error = error {
            completionHandler?(false, error)
        } else {
            completionHandler?(true, nil)
        }
        completionHandler = nil // 清空闭包
    }
    
    // MARK: - 删除所有照片（危险操作！）
        func deleteAllPhotos(completion: @escaping (Bool, Error?) -> Void) {
            // 先检查权限
            let status = PHPhotoLibrary.authorizationStatus()
            
            switch status {
            case .authorized:
                performDelete(completion: completion)
            case .notDetermined:
                PHPhotoLibrary.requestAuthorization { [weak self] newStatus in
                    if newStatus == .authorized {
                        self?.performDelete(completion: completion)
                    } else {
                        DispatchQueue.main.async {
                            completion(false, NSError(
                                domain: "PhotoError",
                                code: 3001,
                                userInfo: [NSLocalizedDescriptionKey: "相册权限被拒绝"]
                            ))
                        }
                    }
                }
            default:
                DispatchQueue.main.async {
                    completion(false, NSError(
                        domain: "PhotoError",
                        code: 3002,
                        userInfo: [NSLocalizedDescriptionKey: "无相册访问权限"]
                    ))
                }
            }
        }
        
        private func performDelete(completion: @escaping (Bool, Error?) -> Void) {
            // 获取所有图片资源（⚠️ 注意：这里会删除所有图片）
            let assets = PHAsset.fetchAssets(with: .image, options: nil)
            
            PHPhotoLibrary.shared().performChanges({
                PHAssetChangeRequest.deleteAssets(assets as NSFastEnumeration)
            }) { success, error in
                DispatchQueue.main.async {
                    if success {
                        completion(true, nil)
                    } else {
                        completion(false, error ?? NSError(
                            domain: "PhotoError",
                            code: 3003,
                            userInfo: [NSLocalizedDescriptionKey: "未知删除错误"]
                        ))
                    }
                }
            }
        }
}

