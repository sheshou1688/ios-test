//
//  vn_pay_terminalApp.swift
//  vn-pay-terminal
//
//  Created by sheshou on 2024/10/29.
//

import SwiftUI

@main
struct vn_pay_terminalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
