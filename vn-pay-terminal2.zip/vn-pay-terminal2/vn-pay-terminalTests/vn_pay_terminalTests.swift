//
//  vn_pay_terminalTests.swift
//  vn-pay-terminalTests
//
//  Created by sheshou on 2024/10/29.
//

import Testing
@testable import vn_pay_terminal

struct vn_pay_terminalTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
